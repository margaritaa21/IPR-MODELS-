import numpy as np

class IPRModels:
    """
    Generación de curvas IPR (Inflow Performance Relationship).
    Retorna tuplas (caudales, presiones) para graficar.
    """

    @staticmethod
    def vogel(q_max, p_res, steps=20):
        """
        Método de Vogel para yacimientos saturados.
        Inputs: Q_max, Presión Yacimiento.
        """
        # Generar presiones de 0 a Presión de yacimiento
        pwf_values = np.linspace(0, p_res, steps)
        q_values = []
        
        for pwf in pwf_values:
            ratio = pwf / p_res
            # Ecuación clásica de Vogel
            q = q_max * (1 - 0.2 * ratio - 0.8 * (ratio ** 2))
            q_values.append(max(0, q))
            
        return np.array(q_values), pwf_values

    @staticmethod
    def darcy(k, h, mu, bo, re, rw, s, p_res, steps=20):
        """
        Método de Darcy (Flujo semi-estacionario).
        Inputs: 
        k (md), h (ft), mu (cp), bo (rb/stb), 
        re (ft), rw (ft), s (adimensional), Pr (psi)
        """
        pwf_values = np.linspace(0, p_res, steps)
        q_values = []
        
        # Validación básica para evitar división por cero
        if mu <= 0 or bo <= 0 or re <= rw:
            return np.zeros(steps), pwf_values
        
        # Constante J (Índice de Productividad)
        # Q = J * (Pr - Pwf)
        # J = (0.00708 * k * h) / (mu * Bo * (ln(re/rw) - 0.75 + S))
        
        try:
            denom = mu * bo * (np.log(re/rw) - 0.75 + s)
            if denom == 0: denom = 1e-6
            j_index = (0.00708 * k * h) / denom
        except Exception:
            j_index = 0

        for pwf in pwf_values:
            q = j_index * (p_res - pwf)
            q_values.append(max(0, q))
            
        return np.array(q_values), pwf_values

    @staticmethod
    def fetkovich(C, n, p_res, steps=20):
        """
        Método de Fetkovich.
        Q = C * (Pr^2 - Pwf^2)^n
        Inputs: C (coeficiente), n (exponente de turbulencia), Pr
        """
        pwf_values = np.linspace(0, p_res, steps)
        q_values = []
        
        for pwf in pwf_values:
            term = (p_res ** 2) - (pwf ** 2)
            if term < 0: term = 0
            q = C * (term ** n)
            q_values.append(q)
            
        return np.array(q_values), pwf_values

    @staticmethod
    def wiggins(q_max, p_res, steps=20):
        """
        Método de Wiggins (Modelo bifásico agua/aceite generalizado).
        Inputs: Q_max, Pr
        Usa coeficientes típicos: q/qmax = 1 - 0.52(ratio) - 0.48(ratio^2)
        """
        pwf_values = np.linspace(0, p_res, steps)
        q_values = []
        
        for pwf in pwf_values:
            ratio = pwf / p_res
            # Polinomio de Wiggins
            q = q_max * (1 - 0.52 * ratio - 0.48 * (ratio ** 2)) 
            q_values.append(max(0, q))
            
        return np.array(q_values), pwf_values