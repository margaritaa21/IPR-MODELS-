import tkinter as tk
from tkinter import ttk
from ui.styles import VioletTheme
from ui.tab_ipr import IPRTab
from ui.tab_vlp import VLPTab

class MainWindow(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("VIOLET - Análisis Nodal & PVT")
        self.geometry("1000x700")
        self.configure(bg=VioletTheme.BG_COLOR)
        
        VioletTheme.apply_styles(self)
        self.build_ui()

    def build_ui(self):
        # Header
        header = tk.Frame(self, bg=VioletTheme.HEADER_COLOR, height=60)
        header.pack(fill=tk.X)
        
        tk.Label(
            header, 
            text="🛢️ VIOLET: Petroleum Production System",
            bg=VioletTheme.HEADER_COLOR,
            fg="white",
            font=(VioletTheme.FONT_FAMILY, 16, "bold")
        ).pack(pady=15)

        # Notebook
        notebook = ttk.Notebook(self)
        notebook.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        # Pestañas
        tab_ipr = IPRTab(notebook)
        tab_vlp = VLPTab(notebook)
        
        notebook.add(tab_ipr, text="  Curvas IPR  ")
        notebook.add(tab_vlp, text="  VLP & Nodal  ")