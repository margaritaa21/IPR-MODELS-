import tkinter as tk
from tkinter import ttk
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

class GraphWidget(ttk.Frame):
    """
    Widget reutilizable para gráficas Matplotlib en Tkinter.
    """
    def __init__(self, parent, title="Gráfica"):
        super().__init__(parent)
        self.figure, self.ax = plt.subplots(figsize=(5, 4), dpi=100)
        
        # Estilo de la gráfica para coincidir con el tema
        self.figure.patch.set_facecolor('#E8D8F1')
        self.ax.set_facecolor('#FDFDFD')
        
        self.canvas = FigureCanvasTkAgg(self.figure, self)
        self.canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)
        
        self.set_labels("Caudal Q [STB/d]", "Pwf [psi]", title)

    def set_labels(self, xlabel, ylabel, title):
        self.ax.set_xlabel(xlabel, fontsize=9, fontname="Century Gothic")
        self.ax.set_ylabel(ylabel, fontsize=9, fontname="Century Gothic")
        self.ax.set_title(title, fontsize=11, fontname="Century Gothic", weight='bold')
        self.ax.grid(True, linestyle='--', alpha=0.6)

    def plot_curve(self, x, y, label, color, clear=False):
        if clear:
            self.ax.clear()
            self.set_labels("Caudal Q [STB/d]", "Pwf [psi]", "Análisis Nodal")
            
        self.ax.plot(x, y, label=label, color=color, linewidth=2)
        self.ax.legend()
        self.canvas.draw()