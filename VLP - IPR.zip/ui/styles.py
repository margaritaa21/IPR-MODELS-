from tkinter import ttk

class VioletTheme:
    """
    Configuración centralizada de estilos (Tema Lavanda).
    """
    BG_COLOR = "#E8D8F1"       # Lavanda claro
    HEADER_COLOR = "#5D3A7A"   # Morado oscuro
    BTN_COLOR = "#8A56AC"      # Morado medio
    TEXT_COLOR = "#2E2133"     # Casi negro
    FONT_FAMILY = "Century Gothic"
    
    @staticmethod
    def apply_styles(root):
        style = ttk.Style()
        style.theme_use("clam")
        
        # Configuración General
        style.configure(".", 
                        background=VioletTheme.BG_COLOR, 
                        foreground=VioletTheme.TEXT_COLOR, 
                        font=(VioletTheme.FONT_FAMILY, 10))
        
        # Notebook (Pestañas)
        style.configure("TNotebook", background=VioletTheme.BG_COLOR, borderwidth=0)
        style.configure("TNotebook.Tab", 
                        background=VioletTheme.BTN_COLOR, 
                        foreground="#F9F9F9", 
                        padding=(15, 5),
                        font=(VioletTheme.FONT_FAMILY, 10, "bold"))
        style.map("TNotebook.Tab",
                  background=[("selected", VioletTheme.HEADER_COLOR)],
                  foreground=[("selected", "#FFFFFF")])
        
        # Botones
        style.configure("TButton", 
                        background=VioletTheme.BTN_COLOR, 
                        foreground="white", 
                        font=(VioletTheme.FONT_FAMILY, 10, "bold"),
                        borderwidth=0)
        style.map("TButton",
                  background=[("active", VioletTheme.HEADER_COLOR)])
        
        # Frames y Labels
        style.configure("TFrame", background=VioletTheme.BG_COLOR)
        style.configure("TLabel", background=VioletTheme.BG_COLOR, foreground=VioletTheme.TEXT_COLOR)
        
        # Entry
        style.configure("TEntry", fieldbackground="white", foreground="black")