import tkinter as tk
from tkinter import ttk, messagebox
from logic.ipr_models import IPRModels
from ui.graph_widget import GraphWidget

class IPRTab(ttk.Frame):
    def __init__(self, parent):
        super().__init__(parent)
        self.entries = {}  # Diccionario para guardar referencias a los inputs dinámicos
        self.setup_ui()

    def setup_ui(self):
        # --- DISEÑO GENERAL ---
        # Panel Izquierdo: Configuración y Datos (Scrollable si hay muchos datos)
        left_panel = tk.Frame(self, bg="#E8D8F1", width=320)
        left_panel.pack(side=tk.LEFT, fill=tk.Y, padx=5, pady=5)
        left_panel.pack_propagate(False) # Forzar ancho fijo

        # Panel Derecho: Gráfica (Arriba) y Tabla (Abajo)
        right_panel = tk.Frame(self)
        right_panel.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True, padx=5, pady=5)

        # --- PANEL IZQUIERDO: SELECCIÓN DE MODELO ---
        lbl_frame_model = ttk.LabelFrame(left_panel, text="Selección de Modelo", padding=10)
        lbl_frame_model.pack(fill=tk.X, padx=5, pady=5)

        ttk.Label(lbl_frame_model, text="Modelo IPR:").pack(anchor="w")
        self.modelo_cb = ttk.Combobox(
            lbl_frame_model, 
            values=["Vogel", "Fetkovich", "Wiggins", "Darcy (Semi-Estacionario)"], 
            state="readonly"
        )
        self.modelo_cb.pack(fill=tk.X, pady=5)
        self.modelo_cb.bind("<<ComboboxSelected>>", self.update_input_fields)
        
        # --- PANEL IZQUIERDO: INPUTS DINÁMICOS ---
        self.input_frame = ttk.LabelFrame(left_panel, text="Parámetros de Entrada", padding=10)
        self.input_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

        # Botón Calcular
        btn_calc = ttk.Button(left_panel, text="Calcular Curva IPR", command=self.calculate)
        btn_calc.pack(fill=tk.X, padx=10, pady=20)

        # --- PANEL DERECHO: GRÁFICA ---
        graph_frame = tk.Frame(right_panel, bg="white", height=400)
        graph_frame.pack(side=tk.TOP, fill=tk.BOTH, expand=True)
        
        self.graph = GraphWidget(graph_frame, title="Curva IPR")
        self.graph.pack(fill=tk.BOTH, expand=True)

        # --- PANEL DERECHO: TABLA DE RESULTADOS ---
        table_frame = ttk.LabelFrame(right_panel, text="Tabla de Resultados (Pwf vs Q)", padding=5)
        table_frame.pack(side=tk.BOTTOM, fill=tk.X, pady=5, ipady=50) # Altura para la tabla

        # Scrollbar para la tabla
        tree_scroll = ttk.Scrollbar(table_frame)
        tree_scroll.pack(side=tk.RIGHT, fill=tk.Y)

        self.tree = ttk.Treeview(table_frame, columns=("pwf", "q"), show="headings", yscrollcommand=tree_scroll.set, height=6)
        self.tree.heading("pwf", text="Presión de Fondo (psi)")
        self.tree.heading("q", text="Caudal (STB/d)")
        self.tree.column("pwf", anchor="center", width=100)
        self.tree.column("q", anchor="center", width=100)
        self.tree.pack(fill=tk.BOTH, expand=True)
        
        tree_scroll.config(command=self.tree.yview)

        # Inicializar con el primer modelo
        self.modelo_cb.current(0)
        self.update_input_fields()

    def update_input_fields(self, event=None):
        """Limpia y regenera los campos de entrada según el modelo seleccionado."""
        # Limpiar campos anteriores
        for widget in self.input_frame.winfo_children():
            widget.destroy()
        self.entries.clear()

        model = self.modelo_cb.get()

        # Generar campos según selección
        if model == "Vogel":
            self.create_entry("Presión Yac. (psi):", "pres", "3000")
            self.create_entry("Q max (STB/d):", "qmax", "1500")
            
            # Nota informativa
            lbl = tk.Label(self.input_frame, text="Modelo para yacimientos\nsaturados (Pwf < Pb).", 
                           fg="#555", font=("Arial", 8, "italic"), justify="left", wraplength=250, bg="#E8D8F1")
            lbl.pack(pady=10, anchor="w")

        elif model == "Fetkovich":
            self.create_entry("Presión Yac. (psi):", "pres", "3000")
            self.create_entry("Coeficiente C:", "c_fet", "0.5")
            self.create_entry("Exponente n (0.5 - 1.0):", "n_fet", "1.0")
            
            lbl = tk.Label(self.input_frame, text="Q = C * (Pr² - Pwf²)^n", 
                           fg="#555", font=("Arial", 8, "italic"), bg="#E8D8F1")
            lbl.pack(pady=10, anchor="w")

        elif model == "Wiggins":
            self.create_entry("Presión Yac. (psi):", "pres", "3000")
            self.create_entry("Q max (STB/d):", "qmax", "1200")
            
            lbl = tk.Label(self.input_frame, text="Modelo trifásico generalizado\n(Agua/Petróleo).", 
                           fg="#555", font=("Arial", 8, "italic"), bg="#E8D8F1")
            lbl.pack(pady=10, anchor="w")

        elif "Darcy" in model:
            self.create_entry("Presión Yac. (psi):", "pres", "3000")
            self.create_entry("Permeabilidad k (md):", "k", "50")
            self.create_entry("Espesor h (ft):", "h", "30")
            self.create_entry("Viscosidad μ (cp):", "mu", "1.5")
            self.create_entry("Factor Vol. Bo (rb/stb):", "bo", "1.2")
            self.create_entry("Radio Drenaje re (ft):", "re", "1000")
            self.create_entry("Radio Pozo rw (ft):", "rw", "0.328") # ~8 pulgadas
            self.create_entry("Skin (s):", "skin", "0")

    def create_entry(self, label_text, key, default_val):
        """Helper para crear filas de inputs."""
        frame = tk.Frame(self.input_frame, bg="#E8D8F1")
        frame.pack(fill=tk.X, pady=2)
        
        lbl = tk.Label(frame, text=label_text, width=20, anchor="w", bg="#E8D8F1")
        lbl.pack(side=tk.LEFT)
        
        entry = ttk.Entry(frame)
        entry.insert(0, default_val)
        entry.pack(side=tk.RIGHT, expand=True, fill=tk.X)
        
        self.entries[key] = entry

    def get_float(self, key):
        """Obtiene valor float de un entry, maneja errores."""
        try:
            val = self.entries[key].get()
            return float(val)
        except (ValueError, KeyError):
            return 0.0

    def calculate(self):
        try:
            # Limpiar gráfica y tabla previa
            self.tree.delete(*self.tree.get_children())
            
            model = self.modelo_cb.get()
            q_res, p_res = [], []

            # Lógica de cálculo según modelo
            if model == "Vogel":
                pres = self.get_float("pres")
                qmax = self.get_float("qmax")
                if pres <= 0: raise ValueError("Presión debe ser > 0")
                q_res, p_res = IPRModels.vogel(qmax, pres)

            elif model == "Fetkovich":
                pres = self.get_float("pres")
                c_val = self.get_float("c_fet")
                n_val = self.get_float("n_fet")
                q_res, p_res = IPRModels.fetkovich(c_val, n_val, pres)

            elif model == "Wiggins":
                pres = self.get_float("pres")
                qmax = self.get_float("qmax")
                q_res, p_res = IPRModels.wiggins(qmax, pres)

            elif "Darcy" in model:
                pres = self.get_float("pres")
                k = self.get_float("k")
                h = self.get_float("h")
                mu = self.get_float("mu")
                bo = self.get_float("bo")
                re = self.get_float("re")
                rw = self.get_float("rw")
                s = self.get_float("skin")
                
                q_res, p_res = IPRModels.darcy(k, h, mu, bo, re, rw, s, pres)

            # Graficar
            color_map = {
                "Vogel": "#2ECC71", 
                "Fetkovich": "#E74C3C", 
                "Wiggins": "#9B59B6", 
                "Darcy (Semi-Estacionario)": "#3498DB"
            }
            color = color_map.get(model, "blue")
            
            self.graph.plot_curve(q_res, p_res, f"IPR - {model}", color, clear=True)

            # Llenar Tabla (Invertimos el orden para mostrar desde Pwf alta a baja o viceversa)
            # Normalmente se muestra de Pwf alta (Q=0) a Pwf baja (Qmax)
            # Los arrays vienen de 0 psi a Pres. Vamos a invertirlos para la tabla visualmente
            
            p_display = p_res[::-1]
            q_display = q_res[::-1]

            for q, p in zip(q_display, p_display):
                self.tree.insert("", "end", values=(f"{p:.2f}", f"{q:.2f}"))

        except ValueError as ve:
            messagebox.showwarning("Error en Datos", f"Verifique los valores numéricos.\n{str(ve)}")
        except Exception as e:
            messagebox.showerror("Error Crítico", f"Ocurrió un error en el cálculo:\n{str(e)}")