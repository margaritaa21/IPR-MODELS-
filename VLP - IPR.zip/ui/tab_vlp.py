import tkinter as tk
from tkinter import ttk, messagebox
import numpy as np
from logic.vlp_models import VLPModels
from logic.ipr_models import IPRModels
from ui.graph_widget import GraphWidget

class VLPTab(ttk.Frame):
    def __init__(self, parent):
        super().__init__(parent)
        self.entries = {}
        self.setup_ui()

    def setup_ui(self):
        # --- LAYOUT PRINCIPAL ---
        # Panel Izquierdo: Inputs
        # Panel Derecho: Gráfica (Arriba) y Tabla (Abajo)
        
        left_panel = tk.Frame(self, bg="#E8D8F1", width=300)
        left_panel.pack(side=tk.LEFT, fill=tk.Y, padx=5, pady=5)
        
        # Canvas para scroll en inputs
        canvas = tk.Canvas(left_panel, bg="#E8D8F1", width=280)
        scrollbar = ttk.Scrollbar(left_panel, orient="vertical", command=canvas.yview)
        self.scroll_frame = ttk.Frame(canvas)
        
        self.scroll_frame.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=self.scroll_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        
        canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

        # --- SECCIONES DE INPUTS ---
        self.add_section("Geometría Pozo", [
            ("Profundidad (ft)", "8000"),
            ("Tubing ID (in)", "2.441"),
            ("Temp. Cabeza (°F)", "100"),
            ("Temp. Fondo (°F)", "200")
        ])

        self.add_section("Datos Producción", [
            ("P Cabeza (psi)", "150"),
            ("API Petróleo", "30"),
            ("Gravedad Gas", "0.75"),
            ("Gravedad Agua", "1.02"),
            ("Bw (rb/stb)", "1.0"),  # Input Bw
            ("GOR (scf/stb)", "800"),
            ("Corte de Agua %", "10")
        ])
        
        self.add_section("Datos IPR (Intersección)", [
            ("Presión Yac. (psi)", "3000"),
            ("Q Max (stb/d)", "6774") # Ejemplo PDF
        ])

        ttk.Button(self.scroll_frame, text="Calcular Análisis Nodal (31 Pasos)", command=self.calculate_nodal).pack(pady=15, fill=tk.X, padx=10)

        # --- PANEL DERECHO ---
        right_panel = tk.Frame(self, bg="#E8D8F1")
        right_panel.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True, padx=10, pady=5)
        
        # Gráfica
        graph_frame = tk.Frame(right_panel, bg="white")
        graph_frame.pack(side=tk.TOP, fill=tk.BOTH, expand=True)
        self.graph = GraphWidget(graph_frame, title="Análisis Nodal (VLP vs IPR)")
        self.graph.pack(fill=tk.BOTH, expand=True)
        
        # Tabla de Variables (31 Pasos)
        table_labelframe = ttk.LabelFrame(right_panel, text="Variables calculadas (Último Punto VLP)", padding=5)
        table_labelframe.pack(side=tk.BOTTOM, fill=tk.X, pady=10, ipady=60)
        
        # Treeview para mostrar las 31 variables
        # Usaremos 2 columnas: Variable y Valor
        self.tree = ttk.Treeview(table_labelframe, columns=("Variable", "Valor"), show="headings", height=8)
        self.tree.heading("Variable", text="Paso / Variable")
        self.tree.heading("Valor", text="Valor Calculado")
        self.tree.column("Variable", width=200)
        self.tree.column("Valor", width=150)
        
        vsb = ttk.Scrollbar(table_labelframe, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=vsb.set)
        
        self.tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        vsb.pack(side=tk.RIGHT, fill=tk.Y)

    def add_section(self, title, fields):
        frame = ttk.LabelFrame(self.scroll_frame, text=title, padding=10)
        frame.pack(fill=tk.X, padx=5, pady=5)
        for i, (lbl, default) in enumerate(fields):
            ttk.Label(frame, text=lbl).grid(row=i, column=0, sticky="w")
            entry = ttk.Entry(frame, width=10)
            entry.insert(0, default)
            entry.grid(row=i, column=1, padx=5)
            self.entries[lbl] = entry

    def get_val(self, key_fragment):
        for k, v in self.entries.items():
            if key_fragment in k:
                try:
                    return float(v.get())
                except ValueError:
                    return 0.0
        return 0.0

    def calculate_nodal(self):
        try:
            # Limpiar tabla
            for item in self.tree.get_children():
                self.tree.delete(item)
                
            # Datos IPR
            pres_res = self.get_val("Presión Yac.")
            q_max_ipr = self.get_val("Q Max")
            
            if pres_res <= 0 or q_max_ipr <= 0:
                 messagebox.showwarning("Datos", "Verifique datos IPR.")
                 return

            # Calcular IPR (Vogel)
            q_ipr, p_ipr = IPRModels.vogel(q_max_ipr, pres_res)
            
            # Calcular VLP (Barrido de caudales)
            # Generamos menos puntos para que sea rápido, pero suficiente para la curva
            q_vlp = np.linspace(100, q_max_ipr, 15) 
            p_vlp = []
            last_details = {}
            
            # Inputs VLP
            depth = self.get_val("Profundidad")
            tid = self.get_val("Tubing")
            pwh = self.get_val("P Cabeza")
            twh = self.get_val("Temp. Cabeza")
            tbh = self.get_val("Temp. Fondo")
            gor = self.get_val("GOR")
            bsw = self.get_val("Corte")
            api = self.get_val("API")
            gsg = self.get_val("Gravedad Gas")
            wsg = self.get_val("Gravedad Agua")
            bw  = self.get_val("Bw")

            for q in q_vlp:
                pwf_calc, details = VLPModels.calculate_pwf_31_steps(
                    depth, tid, pwh, twh, tbh, q, gor, bsw, api, gsg, wsg, bw
                )
                p_vlp.append(pwf_calc)
                last_details = details # Guardamos el último para mostrar en tabla
            
            # Graficar
            self.graph.plot_curve(q_ipr, p_ipr, "IPR (Vogel)", "#2ECC71", clear=True)
            self.graph.plot_curve(q_vlp, p_vlp, "VLP (Calculada)", "#3498DB", clear=False)
            
            # Llenar tabla con los 31 pasos del último punto calculado
            if last_details:
                for key, value in last_details.items():
                    self.tree.insert("", "end", values=(key, f"{value:.4f}"))
                
                # Mensaje de éxito sobre la iteración
                h_calc = last_details.get("Paso 30 (Delta H)", 0)
                messagebox.showinfo("Cálculo Exitoso", 
                                    f"Iteración completada.\nDelta H calculado: {h_calc:.1f} ft\n"
                                    f"Profundidad real: {depth} ft\n"
                                    "Condición H ≈ L cumplida.")

        except Exception as e:
            messagebox.showerror("Error Cálculo", f"Fallo: {str(e)}")
            print(e)